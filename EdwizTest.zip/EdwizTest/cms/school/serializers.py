from rest_framework import serializers
from . import models

class CourseSerializers(serializers.ModelSerializer):

    class Meta():
        model = models.Course
        fields = '__all__'

class StudentSerializers(serializers.ModelSerializer):

    course = serializers.SerializerMethodField('get_courses')

    class Meta():
        model = models.Student
        fields = ['id' , 'name', 'course']
    
    def get_courses(self, student):

        n = []

        for i in student.course_name.all():
            n.append(i.course_name)


        if student.course_name.all() is None:
            return None

        d = {'enrolled_courses': n }
        return d

        


        