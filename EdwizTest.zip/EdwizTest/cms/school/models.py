from tkinter import CASCADE
from django.db import models

# Create your models here.

class Course(models.Model):
    course_name = models.CharField(max_length=30)
    source = models.CharField(max_length=30)

    def __str__(self):
        return self.course_name
class Student(models.Model):
    name = models.CharField(max_length= 30)
    course_name = models.ManyToManyField(Course)

    def __str__(self):
        return self.name