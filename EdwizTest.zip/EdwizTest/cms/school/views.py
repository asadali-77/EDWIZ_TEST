from django.shortcuts import render
from django import views
# Create your views here.
from rest_framework import viewsets
from . import models
from . import serializers 




class CourseView(viewsets.ModelViewSet):
    queryset = models.Course.objects.all()
    serializer_class = serializers.CourseSerializers

class StudentView(viewsets.ModelViewSet):
    queryset = models.Student.objects.all()
    serializer_class = serializers.StudentSerializers
