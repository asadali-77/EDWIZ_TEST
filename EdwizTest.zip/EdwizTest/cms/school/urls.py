from rest_framework.routers import DefaultRouter
from . import views
from django.urls import path , include

router = DefaultRouter()
router.register('courses/' , views.CourseView)
router.register('students/' , views.StudentView)

urlpatterns = [
    path('', include(router.urls) )
]